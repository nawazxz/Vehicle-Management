<li class="menu-header small text-uppercase">
    <span class="menu-header-text"><?php echo e($title); ?></span>
</li>
<?php /**PATH E:\VEHICLE MANAGEMENT\resources\views\components\menu\menu-header.blade.php ENDPATH**/ ?>