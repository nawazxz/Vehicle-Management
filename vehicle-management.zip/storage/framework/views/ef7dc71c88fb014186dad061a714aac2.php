<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            background-color: #121212;
            color: #e0e0e0;
            font-family: Arial, sans-serif;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #333;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #2c2c2c;
        }
        h1, h2 {
            color: #e0e0e0;
        }
    </style>
</head>
<body>
    <h1>Check-in and Check-out Report</h1>
    <div class="col-lg-12">
        <div class="card mb-4">
            <h5 class="card-header">Recent Check-Ins</h5>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Check-In Time</th>
                            <th>Check-In Mileage</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $checkins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $checkin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($checkin->checkin_time); ?></td>
                                <td><?php echo e($checkin->mileage); ?> km</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Recent Check-Outs -->
        <div class="card mb-4">
            <h5 class="card-header">Recent Check-Outs</h5>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Check-Out Time</th>
                            <th>Check-Out Mileage</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $checkouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $checkout): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($checkout->checkout_time); ?></td>
                                <td><?php echo e($checkout->checkout_mileage); ?> km</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Download Report Button -->
        
    </div>
</body>
</html>
<?php /**PATH E:\VEHICLE MANAGEMENT\resources\views\reports.blade.php ENDPATH**/ ?>