<a class="menu-link" href="<?php echo e($href); ?>">
    <?php echo e($slot); ?>

</a>
<?php /**PATH E:\VEHICLE MANAGEMENT\resources\views/components/menu/menu-link.blade.php ENDPATH**/ ?>