<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
    <ul class="py-1 menu-inner">

        <!-- Existing menu items -->
        <?php if (isset($component)) { $__componentOriginal9ab338e123d0f15ae93b479eedf359b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ab338e123d0f15ae93b479eedf359b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.menu.menu-item','data' => ['active' => request()->routeIs('dashboard')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('menu.menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('dashboard'))]); ?>
            <?php if (isset($component)) { $__componentOriginal364681f904ee3a466c139d2e46b1ac23 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal364681f904ee3a466c139d2e46b1ac23 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.menu.menu-link','data' => ['href' => route('dashboard')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('menu.menu-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('dashboard'))]); ?>
                <i class="menu-icon tf-icons bx bx-cube-alt"></i>
                <span>Check-IN-OUT</span>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal364681f904ee3a466c139d2e46b1ac23)): ?>
<?php $attributes = $__attributesOriginal364681f904ee3a466c139d2e46b1ac23; ?>
<?php unset($__attributesOriginal364681f904ee3a466c139d2e46b1ac23); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal364681f904ee3a466c139d2e46b1ac23)): ?>
<?php $component = $__componentOriginal364681f904ee3a466c139d2e46b1ac23; ?>
<?php unset($__componentOriginal364681f904ee3a466c139d2e46b1ac23); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ab338e123d0f15ae93b479eedf359b9)): ?>
<?php $attributes = $__attributesOriginal9ab338e123d0f15ae93b479eedf359b9; ?>
<?php unset($__attributesOriginal9ab338e123d0f15ae93b479eedf359b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ab338e123d0f15ae93b479eedf359b9)): ?>
<?php $component = $__componentOriginal9ab338e123d0f15ae93b479eedf359b9; ?>
<?php unset($__componentOriginal9ab338e123d0f15ae93b479eedf359b9); ?>
<?php endif; ?>

        <!-- New Expenses menu item -->
        <?php if (isset($component)) { $__componentOriginal9ab338e123d0f15ae93b479eedf359b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ab338e123d0f15ae93b479eedf359b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.menu.menu-item','data' => ['active' => request()->routeIs('expenses')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('menu.menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('expenses'))]); ?>
            <?php if (isset($component)) { $__componentOriginal364681f904ee3a466c139d2e46b1ac23 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal364681f904ee3a466c139d2e46b1ac23 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.menu.menu-link','data' => ['href' => route('expenses')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('menu.menu-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('expenses'))]); ?>
                <i class="menu-icon tf-icons bx bx-dollar"></i>
                <span>Expenses</span>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal364681f904ee3a466c139d2e46b1ac23)): ?>
<?php $attributes = $__attributesOriginal364681f904ee3a466c139d2e46b1ac23; ?>
<?php unset($__attributesOriginal364681f904ee3a466c139d2e46b1ac23); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal364681f904ee3a466c139d2e46b1ac23)): ?>
<?php $component = $__componentOriginal364681f904ee3a466c139d2e46b1ac23; ?>
<?php unset($__componentOriginal364681f904ee3a466c139d2e46b1ac23); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ab338e123d0f15ae93b479eedf359b9)): ?>
<?php $attributes = $__attributesOriginal9ab338e123d0f15ae93b479eedf359b9; ?>
<?php unset($__attributesOriginal9ab338e123d0f15ae93b479eedf359b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ab338e123d0f15ae93b479eedf359b9)): ?>
<?php $component = $__componentOriginal9ab338e123d0f15ae93b479eedf359b9; ?>
<?php unset($__componentOriginal9ab338e123d0f15ae93b479eedf359b9); ?>
<?php endif; ?>

        <!-- Logout menu item -->
        <?php if (isset($component)) { $__componentOriginal9ab338e123d0f15ae93b479eedf359b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ab338e123d0f15ae93b479eedf359b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.menu.menu-item','data' => ['active' => request()->routeIs('logout')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('menu.menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('logout'))]); ?>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>

            <a class="menu-link" href="#" onclick="event.preventDefault(); confirmLogout();">
                <i class="menu-icon tf-icons bx bx-log-out"></i>
                Logout
            </a>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ab338e123d0f15ae93b479eedf359b9)): ?>
<?php $attributes = $__attributesOriginal9ab338e123d0f15ae93b479eedf359b9; ?>
<?php unset($__attributesOriginal9ab338e123d0f15ae93b479eedf359b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ab338e123d0f15ae93b479eedf359b9)): ?>
<?php $component = $__componentOriginal9ab338e123d0f15ae93b479eedf359b9; ?>
<?php unset($__componentOriginal9ab338e123d0f15ae93b479eedf359b9); ?>
<?php endif; ?>

    </ul>
</aside>
<?php /**PATH E:\VEHICLE MANAGEMENT\resources\views/layouts/menu/main.blade.php ENDPATH**/ ?>