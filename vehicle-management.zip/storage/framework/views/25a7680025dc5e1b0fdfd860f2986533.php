<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn btn-md btn-primary'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH E:\VEHICLE MANAGEMENT\resources\views\components\primary-button.blade.php ENDPATH**/ ?>