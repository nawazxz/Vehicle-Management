<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <!-- Check-In Form -->
            <div class="mb-4 col-lg-6">
                <div class="card">
                    <h5 class="card-header">Vehicle Check-In</h5>
                    <div class="card-body">
                        <form action="<?php echo e(route('checkin.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="vehicle_name_checkin" class="form-label">Vehicle Name</label>
                                <input type="text" class="form-control" id="vehicle_name_checkin" name="vehicle_name" value="Revo Champ 2021" readonly>
                            </div>
                            <div class="mb-3">
                                <label for="checkin_time" class="form-label">Check-In Time</label>
                                <input type="datetime-local" class="form-control" id="checkin_time" name="checkin_time" required>
                            </div>
                            <div class="mb-3">
                                <label for="checkin_mileage" class="form-label">Mileage at Check-In (km)</label>
                                <input type="number" step="0.01" class="form-control" id="checkin_mileage" name="mileage" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Check In</button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Check-Out Form -->
            <div class="mb-4 col-lg-6">
                <div class="card">
                    <h5 class="card-header">Vehicle Check-Out</h5>
                    <div class="card-body">
                        <form action="<?php echo e(route('checkout.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="vehicle_name_checkout" class="form-label">Vehicle Name</label>
                                <input type="text" class="form-control" id="vehicle_name_checkout" name="vehicle_name" value="Revo Champ 2021" readonly>
                            </div>
                            <div class="mb-3">
                                <label for="checkout_time" class="form-label">Check-Out Time</label>
                                <input type="datetime-local" class="form-control" id="checkout_time" name="checkout_time" required>
                            </div>
                            <div class="mb-3">
                                <label for="checkout_mileage" class="form-label">Mileage at Check-Out (km)</label>
                                <input type="number" step="0.01" class="form-control" id="checkout_mileage" name="checkout_mileage" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Check Out</button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Average Mileage -->
            <div class="col-lg-12">
                <div class="card mb-4">
                    <h5 class="card-header">Average Mileage</h5>
                    <div class="card-body">
                        <p>The average mileage for the vehicle is: <?php echo e(number_format($averageMileage, 2)); ?> km</p>
                    </div>
                </div>
            </div>

            <!-- Recent Check-Ins -->
            <div class="col-lg-12">
                <div class="card mb-4">
                    <h5 class="card-header">Recent Check-Ins</h5>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Vehicle Name</th>
                                    <th>Check-In Time</th>
                                    <th>Check-In Mileage</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $checkins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $checkin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($checkin->vehicle_name); ?></td>
                                        <td><?php echo e($checkin->checkin_time); ?></td>
                                        <td><?php echo e($checkin->mileage); ?> km</td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Recent Check-Outs -->
                <div class="card mb-4">
                    <h5 class="card-header">Recent Check-Outs</h5>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Vehicle Name</th>
                                    <th>Check-Out Time</th>
                                    <th>Check-Out Mileage</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $checkouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $checkout): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($checkout->vehicle_name); ?></td>
                                        <td><?php echo e($checkout->checkout_time); ?></td>
                                        <td><?php echo e($checkout->checkout_mileage); ?> km</td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Download Report Button -->
                <div class="mb-4">
                    <a href="<?php echo e(route('report.download')); ?>" class="btn btn-secondary">Download Report as PDF</a>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('css'); ?>
    <?php $__env->stopPush(); ?>
    <?php $__env->startPush('script'); ?>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH E:\VEHICLE MANAGEMENT\resources\views/dashboard.blade.php ENDPATH**/ ?>