<li class="menu-item <?php echo e($active ? 'active' : ''); ?>">
    <?php echo e($slot); ?>

</li>
<?php /**PATH D:\Software Development\Web Development\Laravel\vehicle-management\resources\views/components/menu/menu-item.blade.php ENDPATH**/ ?>