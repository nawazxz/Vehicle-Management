<li class="menu-item <?php echo e($active ? 'active' : ''); ?>">
    <?php echo e($slot); ?>

</li>
<?php /**PATH E:\VEHICLE MANAGEMENT\resources\views\components\menu\menu-item.blade.php ENDPATH**/ ?>