<div class="app-brand demo">
    <a href="<?php echo e(url('/')); ?>" class="app-brand-link">
        <span class="app-brand-text demo menu-text fw-bold ms-2">
            <?php if(!empty(trim($__env->yieldContent('title')))): ?>
                <?php echo $__env->yieldContent('title'); ?>
            <?php else: ?>
                <?php echo e(config('app.name', 'Vehicle Management')); ?>

            <?php endif; ?>
        </span>
    </a>

    <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
        <i class="align-middle bx bx-chevron-left bx-sm"></i>
    </a>
</div>

<div class="menu-inner-shadow"></div>
<?php /**PATH E:\VEHICLE MANAGEMENT\resources\views\components\menu\brand.blade.php ENDPATH**/ ?>