<?php if (isset($component)) { $__componentOriginal66080d40165dc237152ede315c1d0309 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66080d40165dc237152ede315c1d0309 = $attributes; } ?>
<?php $component = App\View\Components\ErrorLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('error-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ErrorLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-xxl container-p-y">
        <div class="misc-wrapper">
            <h2 class="mb-2 mx-2">Page Not Found :(</h2>
            <p class="mb-4 mx-2">Oops! 😖 The requested URL was not found on this server.</p>
            <a href="<?php echo e(url('/')); ?>" class="btn btn-primary">Back to home</a>
            <div class="mt-3">
                <img src="<?php echo e(asset('')); ?>assets/img/illustrations/page-misc-error-light.png" alt="page-misc-error-light" width="500" class="img-fluid"
                    data-app-dark-img="illustrations/page-misc-error-dark.png" data-app-light-img="illustrations/page-misc-error-light.png" />
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66080d40165dc237152ede315c1d0309)): ?>
<?php $attributes = $__attributesOriginal66080d40165dc237152ede315c1d0309; ?>
<?php unset($__attributesOriginal66080d40165dc237152ede315c1d0309); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66080d40165dc237152ede315c1d0309)): ?>
<?php $component = $__componentOriginal66080d40165dc237152ede315c1d0309; ?>
<?php unset($__componentOriginal66080d40165dc237152ede315c1d0309); ?>
<?php endif; ?>
<?php /**PATH E:\VEHICLE MANAGEMENT\resources\views\errors\404.blade.php ENDPATH**/ ?>