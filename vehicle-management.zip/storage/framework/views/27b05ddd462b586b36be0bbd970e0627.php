<a class="menu-link" href="<?php echo e($href); ?>">
    <?php echo e($slot); ?>

</a>
<?php /**PATH D:\Software Development\Web Development\Laravel\vehicle-management\resources\views/components/menu/menu-link.blade.php ENDPATH**/ ?>