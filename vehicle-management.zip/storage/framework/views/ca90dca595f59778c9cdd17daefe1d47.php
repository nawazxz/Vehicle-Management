<div class="app-brand justify-content-center">
    <a href="<?php echo e(url('/')); ?>" class="gap-2 app-brand-link">
        <span class="app-brand-text demo text-body fw-bold">
            <?php if(!empty(trim($__env->yieldContent('title')))): ?>
                <?php echo $__env->yieldContent('title'); ?>
            <?php else: ?>
                <?php echo e(config('app.name', 'Laravel')); ?>

            <?php endif; ?>
        </span>
    </a>
</div>
<?php /**PATH E:\VEHICLE MANAGEMENT\resources\views\components\logo.blade.php ENDPATH**/ ?>