<input <?php echo $attributes->merge(['class' => 'form-control']); ?>>
<?php /**PATH E:\VEHICLE MANAGEMENT\resources\views\components\text-input.blade.php ENDPATH**/ ?>