<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <!-- Expense Form -->
            <div class="col-12 col-md-6 mb-4">
                <div class="card">
                    <h5 class="card-header">Add Expense</h5>
                    <div class="card-body">
                        <form action="<?php echo e(route('expenses.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="expense_name" class="form-label">Expense Name</label>
                                <input type="text" class="form-control" id="expense_name" name="name" required>
                            </div>
                            <div class="mb-3">
                                <label for="expense_amount" class="form-label">Amount</label>
                                <input type="number" step="0.01" class="form-control" id="expense_amount" name="amount" required>
                            </div>
                            <div class="mb-3">
                                <label for="expense_date" class="form-label">Date</label>
                                <input type="date" class="form-control" id="expense_date" name="date" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Add Expense</button>
                        </form>
                    </div>
                </div>
            </div>
            
            <!-- Expenses Table -->
            <div class="col-12 col-md-12 col-lg-6">
                <div class="card">
                    <h5 class="card-header">Recent Expenses</h5>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Amount</th>
                                        <th>Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($expense->name); ?></td>
                                            <td><?php echo e($expense->amount); ?></td>
                                            <td><?php echo e($expense->date); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="3" class="text-center">No expenses found.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Download Report Button -->
                <div class="col-12 mb-4 mt-2 text-center">
                    <a href="<?php echo e(route('report.download')); ?>" class="btn btn-secondary">Download Report as PDF</a>
                </div>
            </div>
        </div>

        <!-- Back to Dashboard Button -->
       
    </div>

    <?php $__env->startPush('css'); ?>
    <!-- You can include additional CSS here if needed -->
    <?php $__env->stopPush(); ?>

    <?php $__env->startPush('script'); ?>
    <!-- You can include additional scripts here if needed -->
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH E:\VEHICLE MANAGEMENT\resources\views/expenses/index.blade.php ENDPATH**/ ?>