<a class="menu-link" href="{{ $href }}">
    {{ $slot }}
</a>
