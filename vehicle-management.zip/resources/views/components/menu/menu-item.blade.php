<li class="menu-item {{ $active ? 'active' : '' }}">
    {{ $slot }}
</li>
