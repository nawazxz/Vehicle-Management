<input {!! $attributes->merge(['class' => 'form-control']) !!}>
